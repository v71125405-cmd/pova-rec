package com.povarecorder

import android.app.*
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

/** Screen recorder using MediaProjection, MediaCodec and MediaMuxer. Android 10+. */
class RecorderService : Service() {
    companion object {
        const val ACTION_START = "com.povarecorder.START"
        const val ACTION_STOP = "com.povarecorder.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_FPS = "fps"
        const val EXTRA_LONG_EDGE = "longEdge"
        const val EXTRA_BITRATE = "bitrate"
        const val EXTRA_AUDIO_MODE = "audioMode" // 0 none, 1 playback, 2 mic, 3 both
        private const val CHANNEL = "pova_recording"
        private const val NOTIFICATION_ID = 42
        private const val AUDIO_RATE = 48_000
        private const val AUDIO_CHANNELS = 2
        private const val AUDIO_FRAMES = 1024
        private const val AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT
        private const val AUDIO_QUEUE_CAPACITY = 6
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var display: VirtualDisplay? = null
    private var videoSurface: android.view.Surface? = null
    private var videoCodec: MediaCodec? = null
    private var audioCodec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var playbackRecord: AudioRecord? = null
    private var micRecord: AudioRecord? = null
    private var videoThread: Thread? = null
    private var audioThread: Thread? = null
    private var playbackReaderThread: Thread? = null
    private var micReaderThread: Thread? = null
    private var playbackQueue: ArrayBlockingQueue<ShortArray>? = null
    private var micQueue: ArrayBlockingQueue<ShortArray>? = null
    private val stopping = AtomicBoolean(false)
    private val started = AtomicBoolean(false)
    private val muxerLock = Any()
    private val mainHandler by lazy { Handler(mainLooper) }
    private var videoTrack = -1
    private var audioTrack = -1
    private var muxerStarted = false
    private var muxerCompleted = false
    private var audioExpected = false
    private val pendingSamples = mutableListOf<PendingSample>()
    private var outputUri: Uri? = null
    private var outputPfd: ParcelFileDescriptor? = null
    private var outputName: String? = null

    private data class PendingSample(val track: Int, val bytes: ByteArray, val info: MediaCodec.BufferInfo)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopRecording("Запись остановлена")
            ACTION_START -> {
                if (started.get() || projection != null) {
                    updateNotification("Запись уже запускается или идёт")
                    return START_NOT_STICKY
                }
                stopping.set(false)
                createNotificationChannel()
                val mode = intent.getIntExtra(EXTRA_AUDIO_MODE, 0).coerceIn(0, 3)
                val types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                    (if (Build.VERSION.SDK_INT >= 30 && (mode == 2 || mode == 3)) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
                try {
                    if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, buildNotification("Подготовка записи"), types)
                    else startForeground(NOTIFICATION_ID, buildNotification("Подготовка записи"))
                    beginRecording(intent, mode)
                } catch (e: Exception) {
                    android.util.Log.e("PovaRecorder", "Start failed", e)
                    stopRecording("Ошибка запуска: ${e.localizedMessage ?: e.javaClass.simpleName}")
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun beginRecording(intent: Intent, audioMode: Int) {
        check(Build.VERSION.SDK_INT >= 29) { "Требуется Android 10 или новее" }
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        require(resultCode == Activity.RESULT_OK && data != null) { "Нет разрешения на захват экрана" }

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val screenW = metrics.widthPixels.coerceAtLeast(2)
        val screenH = metrics.heightPixels.coerceAtLeast(2)
        val longEdge = intent.getIntExtra(EXTRA_LONG_EDGE, 1080).coerceIn(480, 2160)
        val ratio = screenW.toFloat() / screenH
        val width = if (screenW >= screenH) longEdge else (longEdge * ratio).roundToInt()
        val height = if (screenW >= screenH) (longEdge / ratio).roundToInt() else longEdge
        val w = (width.coerceAtLeast(2) / 2) * 2
        val h = (height.coerceAtLeast(2) / 2) * 2
        val fps = intent.getIntExtra(EXTRA_FPS, 60).coerceIn(15, 120)
        val bitrate = intent.getIntExtra(EXTRA_BITRATE, 12_000_000).coerceIn(2_000_000, 40_000_000)
        audioExpected = audioMode != 0
        videoTrack = -1
        audioTrack = -1
        muxerStarted = false
        muxerCompleted = false
        pendingSamples.clear()

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        outputName = "Pova_$stamp.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, outputName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/PovaRecorder")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Не удалось создать файл в Movies/PovaRecorder")
        outputPfd = contentResolver.openFileDescriptor(outputUri!!, "w")
            ?: error("Не удалось открыть файл для записи")
        muxer = MediaMuxer(outputPfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data!!)
            ?: error("Android не предоставил MediaProjection")
        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopping.get()) stopRecording("Захват экрана остановлен системой")
            }
        }
        projectionCallback = callback
        projection!!.registerCallback(callback, mainHandler)

        val videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        videoCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
            configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        }
        videoSurface = videoCodec!!.createInputSurface()
        videoCodec!!.start()
        display = projection!!.createVirtualDisplay(
            "PovaRecorder", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, videoSurface, null, null
        ) ?: error("Не удалось создать виртуальный дисплей")

        if (audioExpected) setupAudio(audioMode)
        started.set(true)
        videoThread = Thread({ drainVideo() }, "Pova-Video-Drain").also { it.start() }
        if (audioExpected) startAudioWorkers(audioMode)
        updateNotification("Идёт запись • ${w}×${h} • ${fps} FPS")
    }

    private fun setupAudio(mode: Int) {
        if (mode == 1 || mode == 3) {
            val minBuffer = AudioRecord.getMinBufferSize(AUDIO_RATE, AudioFormat.CHANNEL_IN_STEREO, AUDIO_ENCODING)
            check(minBuffer > 0) { "Устройство не поддерживает захват внутреннего звука" }
            val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            playbackRecord = AudioRecord.Builder()
                .setAudioFormat(AudioFormat.Builder().setEncoding(AUDIO_ENCODING).setSampleRate(AUDIO_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build())
                .setBufferSizeInBytes((minBuffer * 2).coerceAtLeast(AUDIO_FRAMES * AUDIO_CHANNELS * 2 * 2))
                .setAudioPlaybackCaptureConfig(config).build()
            check(playbackRecord!!.state == AudioRecord.STATE_INITIALIZED) { "Не удалось инициализировать захват внутреннего звука" }
            playbackQueue = ArrayBlockingQueue(AUDIO_QUEUE_CAPACITY)
        }
        if (mode == 2 || mode == 3) {
            val minBuffer = AudioRecord.getMinBufferSize(AUDIO_RATE, AudioFormat.CHANNEL_IN_MONO, AUDIO_ENCODING)
            check(minBuffer > 0) { "Устройство не поддерживает запись микрофона" }
            micRecord = AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(AudioFormat.Builder().setEncoding(AUDIO_ENCODING).setSampleRate(AUDIO_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
                .setBufferSizeInBytes((minBuffer * 2).coerceAtLeast(AUDIO_FRAMES * 2 * 2)).build()
            check(micRecord!!.state == AudioRecord.STATE_INITIALIZED) { "Не удалось инициализировать микрофон" }
            micQueue = ArrayBlockingQueue(AUDIO_QUEUE_CAPACITY)
        }
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, AUDIO_RATE, AUDIO_CHANNELS).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, AUDIO_FRAMES * AUDIO_CHANNELS * 2 * 2)
        }
        audioCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).apply {
            configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            start()
        }
    }

    private fun startAudioWorkers(mode: Int) {
        playbackRecord?.let { record ->
            playbackReaderThread = createReaderThread(record, playbackQueue!!, AUDIO_CHANNELS, "Pova-Playback-Reader")
            playbackReaderThread!!.start()
        }
        micRecord?.let { record ->
            micReaderThread = createReaderThread(record, micQueue!!, 1, "Pova-Mic-Reader")
            micReaderThread!!.start()
        }
        audioThread = Thread({ encodeMixedAudio(mode) }, "Pova-Audio-Encoder").also { it.start() }
    }

    private fun createReaderThread(record: AudioRecord, queue: ArrayBlockingQueue<ShortArray>, channels: Int, name: String): Thread {
        return Thread({
            try {
                record.startRecording()
                while (!stopping.get() && !Thread.currentThread().isInterrupted) {
                    val chunk = ShortArray(AUDIO_FRAMES * channels)
                    var offset = 0
                    while (offset < chunk.size && !stopping.get()) {
                        val count = record.read(chunk, offset, chunk.size - offset, AudioRecord.READ_BLOCKING)
                        if (count < 0) error("Ошибка чтения аудио: $count")
                        if (count == 0) continue
                        offset += count
                    }
                    if (offset == chunk.size && !stopping.get()) {
                        if (!queue.offer(chunk, 100, TimeUnit.MILLISECONDS)) {
                            queue.poll()
                            queue.offer(chunk)
                        }
                    }
                }
            } catch (e: Exception) {
                if (!stopping.get()) {
                    android.util.Log.e("PovaRecorder", "$name failed", e)
                    mainHandler.post { if (!stopping.get()) stopRecording("Ошибка захвата аудио: ${e.localizedMessage ?: "неизвестная ошибка"}") }
                }
            }
        }, name)
    }

    private fun encodeMixedAudio(mode: Int) {
        var totalFrames = 0L
        try {
            val playback = playbackQueue
            val mic = micQueue
            while (!stopping.get()) {
                val playbackPcm = if (playback != null) playback.poll(500, TimeUnit.MILLISECONDS) else null
                val micPcm = if (mic != null) mic.poll(500, TimeUnit.MILLISECONDS) else null
                if (stopping.get()) break
                if (playback != null && playbackPcm == null) error("Нет данных внутреннего звука")
                if (mic != null && micPcm == null) error("Нет данных микрофона")
                val mixed = ShortArray(AUDIO_FRAMES * AUDIO_CHANNELS)
                if (playbackPcm != null) playbackPcm.copyInto(mixed)
                if (micPcm != null) {
                    for (i in 0 until AUDIO_FRAMES) {
                        val sample = micPcm[i].toInt()
                        val left = (mixed[i * 2].toInt() + sample).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        val right = (mixed[i * 2 + 1].toInt() + sample).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        mixed[i * 2] = left.toShort()
                        mixed[i * 2 + 1] = right.toShort()
                    }
                }
                feedAudioEncoder(mixed, totalFrames)
                totalFrames += AUDIO_FRAMES
                drainCodec(audioCodec ?: break, true, false)
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (e: Exception) {
            if (!stopping.get()) {
                android.util.Log.e("PovaRecorder", "Audio encoding failed", e)
                mainHandler.post { if (!stopping.get()) stopRecording("Ошибка кодирования аудио: ${e.localizedMessage ?: "неизвестная ошибка"}") }
            }
        }
    }

    private fun feedAudioEncoder(pcm: ShortArray, frameOffset: Long) {
        val codec = audioCodec ?: error("Аудиокодировщик не создан")
        while (!stopping.get()) {
            val index = codec.dequeueInputBuffer(10_000)
            if (index >= 0) {
                val input = codec.getInputBuffer(index) ?: error("Нет входного буфера аудиокодировщика")
                input.clear()
                input.order(ByteOrder.nativeOrder())
                check(input.remaining() >= pcm.size * 2) { "Недостаточный размер входного аудиобуфера" }
                pcm.forEach { input.putShort(it) }
                val pts = frameOffset * 1_000_000L / AUDIO_RATE
                codec.queueInputBuffer(index, 0, pcm.size * 2, pts, 0)
                return
            }
            drainCodec(codec, true, false)
        }
    }

    private fun drainVideo() {
        val codec = videoCodec ?: return
        try {
            while (!stopping.get()) drainCodec(codec, false, false)
        } catch (e: Exception) {
            if (!stopping.get()) {
                android.util.Log.e("PovaRecorder", "Video drain failed", e)
                mainHandler.post { if (!stopping.get()) stopRecording("Ошибка видеокодировщика: ${e.localizedMessage ?: "неизвестная ошибка"}") }
            }
        }
    }

    private fun drainCodec(codec: MediaCodec, audio: Boolean, end: Boolean) {
        val info = MediaCodec.BufferInfo()
        val deadline = if (end) SystemClock.elapsedRealtime() + 3000L else Long.MAX_VALUE
        while (true) {
            val index = codec.dequeueOutputBuffer(info, if (end) 10_000 else 10_000)
            when {
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> addTrack(codec.outputFormat, audio)
                index >= 0 -> {
                    val buffer = codec.getOutputBuffer(index)
                    if (buffer != null && info.size > 0) writeSample(audio, buffer, info)
                    val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    codec.releaseOutputBuffer(index, false)
                    if (eos) return
                }
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!end || SystemClock.elapsedRealtime() >= deadline) return
                }
                else -> if (!end || SystemClock.elapsedRealtime() >= deadline) return
            }
        }
    }

    private fun addTrack(format: MediaFormat, audio: Boolean) = synchronized(muxerLock) {
        val m = muxer ?: return@synchronized
        if (audio) {
            if (audioTrack < 0) audioTrack = m.addTrack(format)
        } else {
            if (videoTrack < 0) videoTrack = m.addTrack(format)
        }
        if (!muxerStarted && videoTrack >= 0 && (!audioExpected || audioTrack >= 0)) {
            m.start()
            muxerStarted = true
            pendingSamples.forEach { sample ->
                m.writeSampleData(sample.track, java.nio.ByteBuffer.wrap(sample.bytes), sample.info)
            }
            pendingSamples.clear()
        }
    }

    private fun writeSample(audio: Boolean, source: java.nio.ByteBuffer, info: MediaCodec.BufferInfo) = synchronized(muxerLock) {
        val track = if (audio) audioTrack else videoTrack
        if (track < 0) return@synchronized
        val duplicate = source.duplicate()
        duplicate.position(info.offset)
        duplicate.limit(info.offset + info.size)
        if (muxerStarted) {
            muxer?.writeSampleData(track, duplicate, info)
        } else {
            // Keep only a bounded pre-roll while waiting for both output formats.
            if (pendingSamples.size >= 600) error("Слишком долго ожидалась аудиодорожка")
            val bytes = ByteArray(info.size)
            duplicate.get(bytes)
            val copy = MediaCodec.BufferInfo().apply { set(0, info.size, info.presentationTimeUs, info.flags) }
            pendingSamples.add(PendingSample(track, bytes, copy))
        }
    }

    private fun stopRecording(message: String) {
        if (!stopping.compareAndSet(false, true)) return
        try { display?.release() } catch (_: Exception) { }
        display = null
        try { playbackRecord?.stop() } catch (_: Exception) { }
        try { micRecord?.stop() } catch (_: Exception) { }
        playbackReaderThread?.interrupt()
        micReaderThread?.interrupt()
        audioThread?.interrupt()
        try { playbackReaderThread?.join(1000) } catch (_: Exception) { }
        try { micReaderThread?.join(1000) } catch (_: Exception) { }
        try { audioThread?.join(1500) } catch (_: Exception) { }
        try { videoThread?.join(1500) } catch (_: Exception) { }
        try { playbackRecord?.release() } catch (_: Exception) { }
        try { micRecord?.release() } catch (_: Exception) { }
        playbackRecord = null
        micRecord = null
        playbackQueue?.clear()
        micQueue?.clear()
        playbackQueue = null
        micQueue = null

        try {
            audioCodec?.let { codec ->
                val deadline = SystemClock.elapsedRealtime() + 2000L
                var eosQueued = false
                while (!eosQueued && SystemClock.elapsedRealtime() < deadline) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        eosQueued = true
                    } else {
                        drainCodec(codec, true, false)
                    }
                }
                drainCodec(codec, true, true)
            }
        } catch (e: Exception) { android.util.Log.w("PovaRecorder", "Audio finalization failed", e) }
        try { videoCodec?.signalEndOfInputStream() } catch (_: Exception) { }
        try { videoCodec?.let { drainCodec(it, false, true) } }
        catch (e: Exception) { android.util.Log.w("PovaRecorder", "Video finalization failed", e) }

        try { audioCodec?.stop() } catch (_: Exception) { }
        try { audioCodec?.release() } catch (_: Exception) { }
        try { videoCodec?.stop() } catch (_: Exception) { }
        try { videoCodec?.release() } catch (_: Exception) { }
        try { videoSurface?.release() } catch (_: Exception) { }
        audioCodec = null
        videoCodec = null
        videoSurface = null
        audioThread = null
        videoThread = null
        playbackReaderThread = null
        micReaderThread = null

        synchronized(muxerLock) {
            muxerCompleted = muxerStarted
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) { muxerCompleted = false }
            try { muxer?.release() } catch (_: Exception) { muxerCompleted = false }
            muxer = null
            muxerStarted = false
            pendingSamples.clear()
        }
        try { outputPfd?.close() } catch (_: Exception) { }
        outputPfd = null
        val savedUri = outputUri
        try {
            if (savedUri != null && muxerCompleted) {
                val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(savedUri, values, null, null)
            } else if (savedUri != null) {
                contentResolver.delete(savedUri, null, null)
            }
        } catch (e: Exception) {
            android.util.Log.e("PovaRecorder", "Unable to publish recording", e)
            savedUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) { } }
            muxerCompleted = false
        }

        try { projectionCallback?.let { projection?.unregisterCallback(it) } } catch (_: Exception) { }
        projectionCallback = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        val savedName = if (muxerCompleted) outputName else null
        outputUri = null
        outputName = null
        started.set(false)
        val detail = if (savedName != null) "$message • $savedName" else "$message • файл не сохранён"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, buildNotification(detail))
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, RecorderService::class.java).setAction(ACTION_STOP)
        val stop = if (Build.VERSION.SDK_INT >= 26) {
            PendingIntent.getForegroundService(this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        } else {
            @Suppress("DEPRECATION") PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            else @Suppress("DEPRECATION") Notification.Builder(this)
        val ongoing = started.get() || text == "Подготовка записи"
        builder.setContentTitle("Pova Recorder").setContentText(text)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(ongoing)
        if (ongoing) builder.addAction(Notification.Action.Builder(null, "Остановить", stop).build())
        return builder.build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
                NotificationChannel(CHANNEL, "Запись экрана", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        if (!stopping.get() && (projection != null || videoCodec != null || outputUri != null)) {
            stopRecording("Служба завершена")
        }
        super.onDestroy()
    }
}
