package com.povarecorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaCodecList
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import android.util.TypedValue

class MainActivity : Activity() {
    private val requestCapture = 1001
    private val requestMic = 1002
    private lateinit var status: TextView
    private lateinit var fpsSpinner: Spinner
    private lateinit var qualitySpinner: Spinner
    private lateinit var bitrateSpinner: Spinner
    private lateinit var audioSpinner: Spinner
    private var pendingStart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 20, 18)
        window.navigationBarColor = Color.rgb(16, 20, 18)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(16, 20, 18))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setPadding(0, 12, 0, 8)
        }
        root.addView(label("POVA RECORDER", 25f).apply {
            setTextColor(Color.rgb(57, 217, 138)); gravity = Gravity.CENTER
        }, matchWrap())
        root.addView(label("Запись экрана • MP4 / H.264"), matchWrap())

        root.addView(label("Частота кадров"), matchWrap())
        fpsSpinner = spinner(listOf("30 FPS", "60 FPS", "90 FPS", "120 FPS"))
        root.addView(fpsSpinner, matchWrap())

        root.addView(label("Качество"), matchWrap())
        qualitySpinner = spinner(listOf("1080 px по длинной стороне", "720 px по длинной стороне"))
        root.addView(qualitySpinner, matchWrap())

        root.addView(label("Битрейт"), matchWrap())
        bitrateSpinner = spinner(listOf("8 Мбит/с", "12 Мбит/с", "20 Мбит/с", "30 Мбит/с"))
        bitrateSpinner.setSelection(1)
        root.addView(bitrateSpinner, matchWrap())

        root.addView(label("Источник звука"), matchWrap())
        audioSpinner = spinner(listOf(
            "Без звука",
            "Внутренний звук приложений и игр",
            "Микрофон",
            "Внутренний звук + микрофон"
        ))
        audioSpinner.setSelection(1)
        root.addView(audioSpinner, matchWrap())

        root.addView(Button(this).apply {
            text = "ПРОВЕРИТЬ ВОЗМОЖНОСТИ"
            setOnClickListener { showCapabilities() }
        }, matchWrap())
        root.addView(Button(this).apply {
            text = "НАЧАТЬ ЗАПИСЬ"
            setOnClickListener { requestStart() }
        }, matchWrap())
        root.addView(Button(this).apply {
            text = "ОСТАНОВИТЬ ЗАПИСЬ"
            setOnClickListener {
                startService(Intent(this@MainActivity, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
                status.text = "Команда остановки отправлена."
            }
        }, matchWrap())

        status = label("Готово. Выберите параметры записи.", 14f).apply { setTextColor(Color.LTGRAY) }
        root.addView(status, matchWrap())
        root.addView(label("Файлы сохраняются в общедоступную папку Movies/PovaRecorder. Внутренний звук доступен на Android 10+ и только для приложений, разрешающих захват аудио.", 12f))
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }

    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun requestStart() {
        val audioMode = audioSpinner.selectedItemPosition
        if (audioMode != 0 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStart = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestMic)
            return
        }
        launchCaptureConsent()
    }

    private fun launchCaptureConsent() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    private fun showCapabilities() {
        val fps = intArrayOf(30, 60, 90, 120)
        val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
        val candidates = mutableListOf<String>()
        for (info in codecList.codecInfos) {
            if (!info.isEncoder) continue
            for (type in info.supportedTypes) {
                if (!type.equals("video/avc", true)) continue
                try {
                    val caps = info.getCapabilitiesForType(type).videoCapabilities
                    val supported = fps.filter { rate ->
                        try {
                            // Query typical portrait modes; actual screen dimensions are checked at runtime.
                            caps.areSizeAndRateSupported(1080, 2400, rate.toDouble()) ||
                                caps.areSizeAndRateSupported(720, 1600, rate.toDouble())
                        } catch (_: Exception) { false }
                    }
                    if (supported.isNotEmpty()) candidates.add("${info.name}: ${supported.joinToString()} FPS")
                } catch (_: Exception) { }
            }
        }
        @Suppress("DEPRECATION")
        val hz = windowManager.defaultDisplay.refreshRate
        val message = buildString {
            append("Частота дисплея: %.0f Гц\n\n".format(hz))
            append("Подходящие AVC-кодировщики для типовых размеров:\n")
            append(if (candidates.isEmpty()) "Не найдены" else candidates.joinToString("\n"))
            append("\n\nЭто предварительная проверка. Реальная частота зависит от дисплея, прошивки и нагрузки.")
        }
        status.text = message
        android.app.AlertDialog.Builder(this).setTitle("Возможности устройства")
            .setMessage(message).setPositiveButton("OK", null).show()
    }

    @Deprecated("Deprecated Android result API retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            pendingStart = false
            if (resultCode != RESULT_OK || data == null) {
                status.text = "Разрешение на запись экрана не предоставлено."
                return
            }
            val fps = intArrayOf(30, 60, 90, 120)[fpsSpinner.selectedItemPosition]
            val scale = if (qualitySpinner.selectedItemPosition == 0) 1080 else 720
            val bitrates = intArrayOf(8_000_000, 12_000_000, 20_000_000, 30_000_000)
            val serviceIntent = Intent(this, RecorderService::class.java).apply {
                action = RecorderService.ACTION_START
                putExtra(RecorderService.EXTRA_RESULT_CODE, resultCode)
                putExtra(RecorderService.EXTRA_DATA, data)
                putExtra(RecorderService.EXTRA_FPS, fps)
                putExtra(RecorderService.EXTRA_LONG_EDGE, scale)
                putExtra(RecorderService.EXTRA_BITRATE, bitrates[bitrateSpinner.selectedItemPosition])
                putExtra(RecorderService.EXTRA_AUDIO_MODE, audioSpinner.selectedItemPosition)
            }
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
                status.text = "Запись запускается. Следите за уведомлением."
            } catch (e: Exception) {
                status.text = "Не удалось запустить службу: ${e.localizedMessage ?: "ошибка Android"}"
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestMic) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && pendingStart) {
                pendingStart = false
                launchCaptureConsent()
            } else {
                pendingStart = false
                status.text = "Доступ к микрофону не предоставлен. Отключите запись микрофона или разрешите доступ."
            }
        }
    }
}
